
package previojava.modelos;


public class reaccion {
    private int idPublicacion;
    private int idPersona;

    public reaccion() {
    }

    public reaccion(int idPublicacion, int idPersona) {
        this.idPublicacion = idPublicacion;
        this.idPersona = idPersona;

    }

    public int getIdPublicacion() {
        return idPublicacion;
    }

    public void setIdPublicacion(int idPublicacion) {
        this.idPublicacion = idPublicacion;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    
}
