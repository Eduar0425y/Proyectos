package previojava.modelos;

public class Compartir {
    
    private int idPublicacion;
    private int idPeronaComparte;
    private int idPersonaDestino;

    public Compartir() {
    }

    public Compartir(int idPublicacion, int idPeronaComparte, int idPersonaDestino) {
        this.idPublicacion = idPublicacion;
        this.idPeronaComparte = idPeronaComparte;
        this.idPersonaDestino = idPersonaDestino;
    }

    public int getIdPublicacion() {
        return idPublicacion;
    }

    public void setIdPublicacion(int idPublicacion) {
        this.idPublicacion = idPublicacion;
    }

    public int getIdPeronaComparte() {
        return idPeronaComparte;
    }

    public void setIdPeronaComparte(int idPeronaComparte) {
        this.idPeronaComparte = idPeronaComparte;
    }

    public int getIdPersonaDestino() {
        return idPersonaDestino;
    }

    public void setIdPersonaDestino(int idPersonaDestino) {
        this.idPersonaDestino = idPersonaDestino;
    }
    
    
    
}
