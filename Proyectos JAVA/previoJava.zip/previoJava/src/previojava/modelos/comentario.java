
package previojava.modelos;
/**
 *
 * @author Eduar Xavier
 */
public class comentario {
    private int idComentario;
    private int idPublicacion;
    private int idPersona;
    private String comentario;

    public comentario() {
    }

    public comentario(int idComentario, int idPublicacion, String comentario, int idPersona) {
        this.idComentario = idComentario;
        this.idPublicacion = idPublicacion;
        this.idPersona = idPersona;
        this.comentario = comentario;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public int getIdComentario() {
        return idComentario;
    }

    public void setIdComentario(int idComentario) {
        this.idComentario = idComentario;
    }

    public int getIdPublicacion() {
        return idPublicacion;
    }

    public void setIdPublicacion(int idPublicacion) {
        this.idPublicacion = idPublicacion;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }
    
    
}
