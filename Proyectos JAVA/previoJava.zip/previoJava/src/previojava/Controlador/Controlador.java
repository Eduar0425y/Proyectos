package previojava.Controlador;

import java.util.ArrayList;
   
import java.util.ArrayList;
import previojava.modelos.*;
import previojava.Vistas.*;

public class Controlador {
    
    private publicacion publicacion;
    private vistaApp vistaApp;
    private persona persona;
    private int i=0;
    private int r=0;
    private ArrayList<publicacion> arrayListPublicaciones= new ArrayList<>();
    private ArrayList<reaccion> arrayListMeGusta= new ArrayList<>();
    private ArrayList<Compartir> arrayListCompartir= new ArrayList<>();
    private ArrayList<comentario> arrayListComentarios = new ArrayList<>();

    public Controlador() {
        this.publicacion = new publicacion();
        this.vistaApp = new vistaApp();
        this.persona = new persona();
    }
    
    
    public void inicio(){
        verMenu();
    }
    
    private void verMenu(){
        
        int opcion;
        
        do{
            opcion = Integer.parseInt(vistaApp.getMenu());
            
            switch(opcion){
                case 1: crearPublicacion();
                    break;
                case 2: verPublicacion();
                    break;
                case 3: vistaApp.setTexto("Gracias por usar nuestro programa");
                    break;
                default: vistaApp.setTexto("La opción ingresada no es valida");
            }
        }while(opcion != 3);
    }
    
    private void crearPublicacion(){
        arrayListPublicaciones.add(new publicacion(i, vistaApp.getEntrada("Ingrese el titulo de la publicación: "), vistaApp.getEntrada("Ingrese el contenido de la publicación: ")));
        i++;
    }
    
    private void verPublicacion(){
        
        
        for(int i=0; i < arrayListPublicaciones.size(); i++){
            

            vistaApp.setTexto("\nid de la publicación : " + (arrayListPublicaciones.get(i).getId()+1) + 
                              "\nNombre de la publicación : " + arrayListPublicaciones.get(i).getTitulo() +
                              "\nContenido de la publicación : " + arrayListPublicaciones.get(i).getContenido());
            
        }
        
        switch(vistaApp.verMenuPubli()){
            case "1" :  meGusta();
                break;
            case "2" : comentar();
                break;
            case "3" : compartir();
                break;
            case "4" : verPerosnasCompartir(persona.getArrayListPersonas());
                break;
            case "5" : verComentarios(persona.getArrayListPersonas());
                break;
            default: vistaApp.setTexto("Será dirijido al menú principal...");
        }
    }
    
    private void meGusta(){
        arrayListMeGusta.add(new reaccion((Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la publicación: "))-1), (Integer.parseInt(vistaApp.getEntrada("Ingrese su id: "))-1)));
        
        vistaApp.setTexto("\nSu me gusta se ha realizado con éxito.\n");

    }
    
    private void comentar(){
        arrayListComentarios.add(new comentario(r,(Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la publicación: "))-1), vistaApp.getEntrada("Ingrese el comentario: ") ,(Integer.parseInt(vistaApp.getEntrada("Ingrese su id: "))-1)));
        r++;
    }
    
    private void verComentarios(ArrayList<persona> arrayListPersonas){
        
        
        int idPubliVerComen = (Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la publicación: "))-1);
              
        for(int e=0; e < arrayListComentarios.size(); e++){
            if(arrayListComentarios.get(e).getIdPublicacion() == idPubliVerComen){
                vistaApp.setTexto("Comentario: " + arrayListComentarios.get(e).getComentario() +
                                  "\nComentario hecho por: " + arrayListPersonas.get(arrayListComentarios.get(e).getIdPersona()).getNombre() + " " + arrayListPersonas.get(arrayListComentarios.get(e).getIdPersona()).getApellido() + "\n");
                
            }
        }

    }
    
    private void compartir(){
        arrayListCompartir.add(new Compartir((Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la publicación: "))-1), (Integer.parseInt(vistaApp.getEntrada("Ingrese su id: "))-1), (Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la persona de destino: "))-1)));
        vistaApp.setTexto("\nLa publicación ha sido compartida con éxito.\n");

    }
    
    private void verPerosnasCompartir(ArrayList<persona> arrayListPersonas){
        
        
        int idCompartida= (Integer.parseInt(vistaApp.getEntrada("Ingrese el id de la publicacion que desea ver las compartidas: "))-1);
        
        
        
        for(int d=0; d<arrayListCompartir.size(); d++){
            if(arrayListCompartir.get(d).getIdPublicacion() == idCompartida){
                vistaApp.setTexto("Perona que compartió: " + arrayListPersonas.get(arrayListCompartir.get(d).getIdPeronaComparte()).getNombre() + 
                                  "\nPerona a la que compartió: " + arrayListPersonas.get(arrayListCompartir.get(d).getIdPersonaDestino()).getNombre());
            }
        }
        
        
    }
    
}


