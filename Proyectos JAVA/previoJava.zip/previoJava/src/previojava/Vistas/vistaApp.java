package previojava.Vistas;

import java.util.Scanner;
import java.util.ArrayList;




public class vistaApp {
    
    private Scanner teclado= new Scanner(System.in);
    
    public String getMenu(){
        
        System.out.println("Bienvenido, ingrese la opción que desea realizar: " + 
                           "\n1. Crear una publicación" +
                           "\n2. Ver las publicaciones" +
                           "\n3. Salir");
        return teclado.nextLine();
    }
    
    public String getEntrada(String texto){
        
        System.out.println(texto);
       
        return teclado.nextLine();
    }
        
    public void setTexto(String texto){
        System.out.println(texto);
    }
    
    
    public String verMenuPubli(){
        System.out.println("Ingrese la opción que desea realizar: " + 
                           "\n1. Dar me gusta" +
                           "\n2. Comentar" +
                           "\n3. Compartir" +
                           "\n4. Ver quien compartió: "+
                           "\n5. Ver comentarios" +
                           "\n6. Salir");
        return teclado.nextLine();
    }
    
 
}
