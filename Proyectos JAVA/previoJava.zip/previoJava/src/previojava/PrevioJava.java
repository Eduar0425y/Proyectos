package previojava;

import previojava.Controlador.Controlador;
import previojava.controlador.*;

public class PrevioJava {


    public static void main(String[] args) {
        Controlador controlador = new Controlador(); 
        controlador.inicio();
    }
    
}

